var mydata = JSON.parse(data);
var showdata='';
for(const props in mydata){
  showdata += `<li><b>Name:</b> ${mydata[props]['Name']},
      <b>Country:</b> ${mydata[props]['Country']}, 
      <b>Gender:</b> ${mydata[props]['Gender']}   </li>`;
}
document.getElementById('showData').innerHTML=showdata;